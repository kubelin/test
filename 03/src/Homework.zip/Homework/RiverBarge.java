package Homework;

public class RiverBarge extends Vehicle{

	@Override
	public double calcFuelEfficiency() {

		return 20.0;
	}

	@Override
	public double calcTripDistance() {
	
		return 100.0;
	}

}
